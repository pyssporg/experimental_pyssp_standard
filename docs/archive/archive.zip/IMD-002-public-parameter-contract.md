---
id: IMD-002
title: Public parameter-set and parameter-mapping contract
summary: Parameter sets and mappings cross the library border as version-neutral Protocol types, not concrete SSP1 classes.
date: 2026-10-27
status: accepted
layers: [implementation]
state: 03-implementation/interfaces.md
artifacts:
  - pyssp_standard/parameters.py
  - pyssp_standard/__init__.py
  - pyssp_standard/ssv.py
  - pyssp_standard/ssm.py
  - pyssp_standard/ssd.py
  - pyssp_standard/standard/ssp1/model/ssm_model.py
  - pyssp_standard/standard/ssp1/operations/parameter_values.py
supersedes: []
superseded_by: []
related: [IMD-001]
---

# IMD-002: Public parameter-set and parameter-mapping contract

## Context
CAP-016 resolved parameters, yet public `ParameterMapping` was the SSP1 dataclass and no `ParameterSet` existed. `SSV.parameters_by_name()` raised for SSP2, `SSM` pinned SSP1, and `ParameterBinding` was unexported. `parameter_values.py` was version-neutral but lived inside the SSP1 stack.

## Decision
Added `pyssp_standard/parameters.py` with the `Parameter`, `ParameterSet`, `MappingEntry`, and `ParameterMapping` protocols plus `parameters_by_name()` and `resolve_parameter_mapping()`. Facades gained `SSV.add_parameter()`, `SSV.extend_parameters()`, and `SSM.add_mapping()`. `parameter_values.py` was deleted; its version-neutral logic moved into `parameters.py`.

## Rationale
Consumer code then works on SSP1 and SSP2 documents without importing `pyssp_standard.standard.*`. Protocol types keep models plain dataclasses that import nothing from the public API. Resolution logic gets one home outside the version-specific stacks.

## Alternatives Considered
- ABC inheritance: versioned models would import the public API.
- Wrapper or adapter classes: extra layer and conversions, no behaviour.
- Facade methods only: no public type for a set or mapping, helper stranded in SSP1.
- Keeping the concrete alias: two meanings for one public name.

## Consequences
- Positive: one version-neutral contract for both SSP2 SSV and SSP1 documents; the public border exports `ParameterBinding`.
- Negative: `ParameterMapping` changed meaning from concrete class to protocol. No consumer inside this workspace instantiated it (internal code uses `Ssp1ParameterMapping`), but external importers break. `runtime_checkable` checks attribute presence only. No binding protocol exists yet.

## Verification
Contract tests satisfy and exercise both versions; full `pytest` passes; `SSV.parameters_by_name()` on an SSP2 document returns parameters instead of raising `TypeError`.

## Review Trigger
When an SSP2 SSM stack or a binding protocol is proposed.
