---
id: IMD-001
title: set_generation_date_and_time placement and scope
summary: Each XML and archive facade sets generationDateAndTime itself, formatting through one shared utility.
date: 2026-05-25
status: accepted
layers: [implementation]
state: 03-implementation/interfaces.md
artifacts:
  - pyssp_standard/common/datetime_utils.py
  - pyssp_standard/ssd.py
  - pyssp_standard/ssv.py
  - pyssp_standard/ssb.py
  - pyssp_standard/ssm.py
  - pyssp_standard/srmd.py
  - pyssp_standard/md.py
  - pyssp_standard/ssp.py
  - pyssp_standard/fmu.py
supersedes: []
superseded_by: []
related: []
---

# IMD-001: set_generation_date_and_time placement and scope

## Context
A feature was added to set `generationDateAndTime` across all XML facades.
The attribute exists in SSP1 document metadata and in FMI2/FMI3 model
descriptions. It had to cover seven XML facades (SSD, SSV, SSB, SSM, SRMD,
ModelDescription) and two archive facades (SSP, FMU), while excluding LS-REF
facades (LSRefManifest, LSRefExperiments), which do not carry the attribute.

## Decision
Each facade implements `set_generation_date_and_time(dt=None)` directly, with
no base-class method. A shared `format_generation_datetime()` utility in
`pyssp_standard/common/datetime_utils.py` formats ISO 8601 with `T`/`Z` and
defaults to `2000-01-01T00:00:00Z`. XML facades assign to the model attribute;
archive facades delegate through their inner context (`SSP.system_structure()`,
`FMU.model_description`). String inputs pass through without validation.

## Rationale
Facades already own the user-facing workflow, so the setter belongs there
rather than in a generic base class. One formatting utility keeps the epoch
default identical across nine call sites and matches the deterministic-build
convention. Delegation reuses the existing context lifecycle instead of
duplicating archive handling.

## Alternatives Considered
- One `XmlDocument` base-class method for every facade.
- Per-facade formatting with no shared utility.
- Extending the setter to LS-REF facades that lack the attribute.

## Consequences
- Consistent public API across all relevant facades.
- No changes to the domain model layer, only facade methods.
- Archive delegation automatically acquires and releases document context.
- LS-REF facades are explicitly excluded, no method added.
- Users create or filter raw strings outside the library; no format validation.
- Test burden covers 9 facades x 6 scenarios, about 54 test cases.

## Verification
Facade tests cover the setter on each facade; `pytest/common/test_generation_date_time.py`
and the generation-date stability guardrail check the default serialization.

## Review Trigger
Revisit if LS-REF gains the attribute, or if callers need format validation.
