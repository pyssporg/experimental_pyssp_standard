---
id: DEC-003
title: Source layout with src/ and tests/
summary: Package sources live under src/pyssp_standard, tests under tests/, and the pytest configuration moves into pyproject.toml.
date: 2026-10-27
status: accepted
layers: [implementation]
state: 03-implementation/code-structure.md
artifacts:
  - pyproject.toml
  - conftest.py
  - src/pyssp_standard/__init__.py
  - tests/conftest.py
supersedes: []
superseded_by: []
related: []
---

# DEC-003: Source layout with `src/` and `tests/`

## Context
Package code and tests sat side by side at the repository root, and `pytest.ini`
pointed `testpaths` at a directory literally named `pytest`. That name shadowed
the `pytest` distribution as a namespace portion on `sys.path`, the root
`conftest.py` force-inserted the repository root into `sys.path`, fixture paths
resolved against the current working directory, and the sibling repositories
(`pyssp_workflow`, `pyssp_sysml2`) already used `src/` plus `tests/` with the
pytest configuration inside `pyproject.toml`.

## Decision
Move package sources to `src/pyssp_standard/` and the test tree to `tests/`,
delete `pytest.ini`, and carry its contents into `pyproject.toml` under
`[tool.pytest.ini_options]` with `testpaths = ["tests"]` and
`pythonpath = ["src"]`. Declare the layout through
`package-dir = {"" = "src"}` and `packages.find where = ["src"]`, and anchor
test fixture paths on `Path(__file__)` instead of the working directory.

## Rationale
A src layout keeps the importable package out of the repository root, so an
in-tree import can only resolve through the installed or editable distribution,
which is the surface a consumer sees. `tests/` removes the collision with the
real `pytest` package and matches the sibling repositories. One configuration
file replaces two, and `__file__`-anchored fixtures let the suite run from any
working directory instead of documenting a required invocation directory.

## Alternatives Considered
- Keep the flat layout and only rename `pytest/` to `tests/`.
- Keep `pytest.ini` alongside a src layout.
- Keep the root `sys.path` insertion instead of the `pythonpath` ini option.
- Keep CWD-relative fixture literals and document "run from the repository root".

## Consequences
- Positive: package and tests can no longer import across the repository border
  by accident; `conftest.py` shrinks to one collection rule; packaging and test
  configuration live in one file.
- Positive: the suite now passes from outside the checkout (407 passed, one
  pre-existing failure) instead of failing on two relative fixture paths.
- Negative: editable installs must be refreshed with `pip install -e .`, because
  the PEP 660 finder maps the package to the old `pyssp_standard/` directory.
- Enforcement: `pytest>=7` is a floor in the `dev` extra, since the
  `pythonpath` ini option does not exist in earlier releases.
- History: DEC-001, DEC-002, and IMD-001 to IMD-006 name pre-move file paths.
  They are dated records and stay unchanged.

## Verification
Editable reinstall, then `import pyssp_standard` resolves to
`src/pyssp_standard/__init__.py`. Suite from the checkout root: 408 passed.
Suite from `/tmp`: 408 passed. The last failure before this change,
`test_ssp_add_fmu.py::test_add_fmu_directory_is_packed_as_nested_fmu_on_archive_commit`,
asserted a `binaries/` entry inside the packed FMU while the vendored
`0001_ECS_HW` fixture carries only `modelDescription.xml`. The test now copies
the fixture to `tmp_path`, adds `binaries/linux64/plant.so`, and asserts that
exact member, so the recursive directory packing is covered without inventing
fixture provenance. Wheel built with `pip wheel --no-deps`: 37
schema XSD files included, no `src/` prefix in member paths, one top-level
package. `pyssp_workflow/tests/test_layering.py`,
`ssp_references/tests/test_artifact_boundaries.py`, and
`ssp_references/tests/test_sysml_fixtures.py` pass against the moved package.

## Review Trigger
When the package is published to PyPI, when a build backend other than
setuptools is adopted, or when a second editable consumer needs a path into the
source tree.
