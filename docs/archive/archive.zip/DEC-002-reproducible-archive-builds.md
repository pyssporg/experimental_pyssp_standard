---
id: DEC-002
title: Reproducible archive builds
summary: Archive creation is deterministic by default, using FMI_EPOCH timestamps, sorted entries, and ZIP_DEFLATED.
date: 2026-06-10
status: accepted
layers: [implementation]
state: 02-architecture/quality-attributes.md
artifacts:
  - pyssp_standard/common/archive.py
  - pyssp_standard/common/archive_runtime.py
  - pyssp_standard/fmu.py
  - pyssp_standard/ssp.py
  - pyssp_standard/common/datetime_utils.py
supersedes: []
superseded_by: []
related: [IMP-022, IMP-028]
---

# DEC-002: Reproducible archive builds

## Context
Build output (FMU archives, SSP archives, XML documents) had to be
byte-identical for identical specification files and the same tool version.
Filesystem mtime timestamps, unsorted entry iteration, and implicit
compression settings each produced a different archive per build, blocking
content-addressed caching, CI comparison, and diff review of generated
artifacts.

## Decision
Adopt `FMI_EPOCH` (2000-01-01 00:00:00) as the canonical zero timestamp for
all archive entries. Sort ZIP entries with `sorted()`, compress with
`ZIP_DEFLATED`, and thread `fixed_timestamp` through `ArchiveRuntime` and
`DirectoryRuntime`. XML `generationDateAndTime` is not auto-injected; it
stays absent unless `set_generation_date_and_time()` is called.

## Rationale
One deterministic timestamp removes the dominant non-determinism source while
matching the epoch used by `format_generation_datetime()`. Sorting and an
explicit compression method remove the remaining platform-dependent ordering
and level choices. Keeping XML generation dates absent avoids reintroducing
`datetime.now()` into created documents.

## Alternatives Considered
- Keep filesystem mtime and normalize only in CI.
- Set `generationDateAndTime` to the current time on creation.
- Add `compresslevel` control as part of the same change.

## Consequences
- All archive creation paths produce deterministic output by default.
- New XML documents omit `generationDateAndTime` (optional in the standards).
- Five acceptance criteria (AC-DET-001 to AC-DET-005) guard against regression.
- Unpacking, directory mode, cross-version builds, and full byte-for-byte
  round-trips stay out of scope.

## Verification
`pytest/fmi2/archive/test_fmu.py::test_fmu_create_deterministic` and the SSP
packaging determinism tests compare SHA256 hashes across two runs.

## Review Trigger
Revisit if a new output path introduces timestamps or ordering, or if the
compression backend changes.
