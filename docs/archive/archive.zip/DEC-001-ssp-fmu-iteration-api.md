---
id: DEC-001
title: SSP FMU iteration API surface
summary: FMU iteration over SSP components ships as an operations-layer function plus a thin SSP delegation method.
date: 2026-05-26
status: accepted
layers: [implementation]
state: 03-implementation/interfaces.md
artifacts:
  - pyssp_standard/standard/ssp1/operations/ssd_fmu_iteration.py
  - pyssp_standard/ssp.py
supersedes: []
superseded_by: []
related: [IMP-019]
---

# DEC-001: SSP FMU iteration API surface

## Context
A safe, lazy API was needed to iterate FMU-backed components inside an SSP.
Three shapes were evaluated: A, an eager property; B, a generator method on
`SSP`; C, a standalone helper. Option A forces every FMU open during access,
and B alone is untestable without an SSP artifact. IMP-019 carried the
candidate and its evidence.

## Decision
Adopt hybrid B+C. A `FmuEntry` dataclass exposes `open_fmu()`; a standalone
`iter_fmu_entries()` lives in the SSP1 operations layer; `SSP.iter_fmu_entries()`
is a thin delegating facade. `skip_missing` defaults to `True`, recursion to
`False`.

## Rationale
The operations layer keeps the traversal testable without an archive and
aligned with layer rules: orchestration owns archive-relative resolution,
the public facade only delegates. Lifecycle stays with the caller, which is
the pattern already used for `FMU` and avoids hidden open handles.

## Alternatives Considered
- A: eager property on `SSP`, opening every FMU on access.
- B: generator method on `SSP` only, with logic inside the facade.
- Returning a context manager instead of an `FMU` handle.

## Consequences
- Operations-layer function testable without an SSP artifact.
- `FmuEntry.open_fmu()` shifts lifecycle to the caller, as expected.
- `skip_missing=True` by default; `skip_missing=False` for power users.
- Extensible with filtering later; additive, no breaking changes.

## Verification
`pytest/ssp1/orchestration/test_ssp_fmu_iteration.py` covers flat, recursive,
missing-source, and delegation cases.

## Review Trigger
Revisit if filtering needs become first-class or SSP2 systems need iteration.
