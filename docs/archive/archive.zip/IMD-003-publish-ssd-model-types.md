---
id: IMD-003
title: Publish SSD model types and concrete parameter types at the package border
summary: Consumers import pyssp_standard only through its top-level surface; the package publishes the SSD tree types and the concrete SSP1 parameter types.
date: 2026-10-27
status: accepted
layers: [implementation]
state: 03-implementation/interfaces.md
artifacts:
  - pyssp_standard/__init__.py
  - pyssp_standard/ssd.py
  - docs/breakdown/03-implementation/interfaces.md
  - docs/breakdown/01-product/domain-model.md
supersedes: []
superseded_by: []
related: [IMD-002]
---

# IMD-003: Publish SSD model types and concrete parameter types at the package border

## Context
Consumers in this workspace (`pyssp_workflow`, `pyssp_sysml2`) imported
`pyssp_standard.ssd`, `.ssm`, `.ssv`, `.ssp`, and `.fmu` submodules instead of
the package surface. Dropping the `pyssp_standard.ssd.ParameterMapping` alias in
IMD-002 then broke `pyssp_sysml2`, which constructed that class. The library
border rule already allows a documented public model type to cross, but a type
is public only when the package exports it deliberately.

## Decision
Export the SSD tree types `Component`, `Connection`, `Connector`,
`DefaultExperiment`, and `System`, plus the concrete SSP1 parameter types
`Ssp1Parameter`, `Ssp1ParameterSet`, and `Ssp1ParameterMapping`, from
`pyssp_standard/__init__.py`. Consumers import every `pyssp_standard` name from
the package top level and stop importing submodules.

## Rationale
The SSD model tree is the canonical in-memory representation that facades expose
through `xml`. Publishing it makes existing traversal legitimate instead of
accidental. The concrete SSP1 parameter types stay available for construction,
while the protocols from IMD-002 stay the version-neutral read/write contract.
One import rule is simpler to teach and to enforce than a per-name allow-list.

## Alternatives Considered
- Restore the `pyssp_standard.ssd.ParameterMapping` alias: one public name with
  two meanings, the exact ambiguity IMD-002 removed.
- Add SSD read/write methods instead of publishing the tree: larger surface that
  still needs named types for test fixtures and annotations.
- Force consumers to build SSP/SSD files only: no public component or system
  builder exists, so fixture construction would move into hand-written XML.

## Consequences
- Positive: consumers use one import form; submodule imports can be rejected
  mechanically; `pyssp_sysml2` works again without touching its pinned
  `pyssp_standard` copy.
- Negative: the package surface grows to 34 names and carries SSP1-specific type
  names (`Ssp1*`, `Component`, `System`) at a version-neutral border. Consumers
  must distinguish the `ParameterMapping` protocol from the
  `Ssp1ParameterMapping` dataclass.
- Enforcement: `pyssp_workflow/tests/test_layering.py` rejects
  `pyssp_standard.<submodule>` imports in `src/` and `tests/`.

## Verification
`pyssp_workflow`: 58 passed, 1 skipped, ruff clean. `pyssp_sysml2`: 163 passed.
`pyssp_standard`: 363 passed, one pre-existing failure in
`test_ssp_add_fmu.py` (the checked-in FMU fixture has no `binaries/`).
Root `tests/test_sysml_fixtures.py`: 51 passed. One internal import remains,
`validate_component_fmu` in `pyssp_sysml2/ssp.py`, because no public equivalent
exists yet.

## Review Trigger
When a public validation facade exists, or when SSP2 SSD/SSM gains model types
that would make the published `System`/`Component` aliases version-neutral.
