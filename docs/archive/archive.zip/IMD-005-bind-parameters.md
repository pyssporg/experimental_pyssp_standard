---
id: IMD-005
title: Move SSP parameter-binding assembly behind SSP.bind_parameters
summary: The provider owns placement, target selection, resource naming, and mapping attach or resolve; the workflow keeps only its placement policy.
date: 2026-10-27
status: accepted
layers: [implementation, product]
state: 03-implementation/interfaces.md
artifacts:
  - pyssp_standard/ssp.py
  - pyssp_standard/standard/ssp1/operations/ssp_binding.py
  - pyssp_standard/standard/ssp1/operations/ssd_parameter_bindings.py
  - pyssp_standard/standard/ssp1/model/ssd_model.py
  - docs/breakdown/03-implementation/interfaces.md
  - docs/breakdown/01-product/capabilities.md
supersedes: []
superseded_by: []
related: [IMD-002, IMD-004]
---

# IMD-005: Move SSP parameter-binding assembly behind `SSP.bind_parameters`

## Context
`pyssp_workflow.binding` composed SSP parameter bindings itself: it named
resources, wrote `resources/<name>` strings, walked the SSD tree for nested
targets, and duplicated the external/inline × attach/flatten matrix. Those are
SSP assembly rules, split across the facade, the codec, the model defaults, and
the caller. Two consumers needed the same nodes: `pyssp_workflow` and
`pyssp_sysml2`.

## Decision
`SSP.bind_parameters(parameter_set, *, mapping, target, placement,
resolve_mapping, name, prefix)` binds one set to the root system, a nested
system, or a component; places it externally or inline; attaches or resolves
the mapping; names the resource and detects collisions. It accepts an `.ssv`
path, a `ParameterSet`, or resolved parameters, and delegates to
`standard/ssp1/operations/ssp_binding.py`.

## Rationale
The mechanics are SSP semantics, not study semantics. Moving them into one
orchestration function gives the name, path, prefix, and collision rules a
single owner, and the two consumers stop composing paths by hand. The layer
rule is satisfied because the facade only delegates; the workflow keeps the
policy it is supposed to own.

## Alternatives Considered
- Leave `bind` in the workflow (AD-005): keeps two implementations of the same
  assembly and leaves the rules split.
- Implement the whole operation inside `ssp.py`: violates
  `02-architecture/layer-rules.md:69-76`, which requires a thin facade.
- Expose only more primitives: the caller still writes `resources/` strings and
  walks the tree, which is the code we wanted gone.

## Consequences
- Positive: one owner for binding assembly; `pyssp_workflow.binding` drops from
  268 to 150 lines and keeps no path or tree logic; `add_external_parameterset`
  now delegates and returns the `ParameterBinding` protocol.
- Negative: `name` is both the optional resource name and the parameter-set
  name, so a caller that renames one renames the other; `prefix` is stored but
  still not applied; resource collisions that used to overwrite now raise
  `FileExistsError`.
- Enforcement: `pyssp_workflow/tests/test_layering.py` keeps the facade read
  rule; the workflow binding tests pin the four placements and the gates.

## Verification
`pyssp_standard`: 391 passed, one pre-existing failure in
`test_ssp_add_fmu.py` (the FMU fixture has no `binaries/`). New
`pytest/ssp1/orchestration/test_ssp_bind.py`: 19 passed. `pyssp_workflow`: 61
passed, 1 skipped; the 18 original binding assertions are unchanged.
`pyssp_sysml2`: 165 passed, no change needed because it builds an SSD artifact,
not an SSP archive.

## Review Trigger
When SSP2 gains an SSM stack, or when a third consumer needs a placement the
method does not express.
