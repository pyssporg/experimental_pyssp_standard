---
id: IMD-006
title: Split parameter binding between SSD and SSP
summary: SSD edits bindings and resolves targets; SSP places archive resources and delegates.
date: 2026-10-27
status: accepted
layers: [architecture, implementation, product]
state: 03-implementation/parameter-binding.md
artifacts:
  - pyssp_standard/ssd.py
  - pyssp_standard/tree.py
  - pyssp_standard/standard/ssp1/model/ssd_model.py
  - pyssp_standard/standard/ssp1/operations/ssd_binding.py
  - pyssp_standard/standard/ssp1/operations/ssp_binding.py
  - docs/breakdown/03-implementation/interfaces.md
  - docs/breakdown/03-implementation/parameter-binding.md
  - docs/breakdown/01-product/capabilities.md
supersedes: []
superseded_by: []
related: [IMD-005, IMD-004]
---

# IMD-006: Split parameter binding between `SSD` and `SSP`

## Context
IMD-005 gave `SSP.bind_parameters` all binding assembly. It reached past the
`SSD` facade into the document tree: it walked `elements`, built
`Ssd1ParameterBinding` and `Ssd1ParameterMappingReference`, and chose the
inline-or-external node shape. `SSD` had no binding operation, so a standalone
`.ssd` could not be edited. Archive concerns and document concerns shared one
335-line module, and the public API layer held assembly logic.

## Decision
`SSD` owns document editing: `target(path)` resolves a dotted path, and
`bind_parameters(...)` adds one binding through
`Element.add_parameter_binding`. `SSP` keeps every file concern — reading,
placement, resource naming, collisions — and delegates the edit with
`ssd.bind_parameters(...)`. Assembly moves to
`standard/ssp1/operations/ssd_binding.py`.

## Rationale
Layer rules put document editing at the model/facade border and archive
resolution in orchestration. The split lets a standalone `.ssd` gain bindings
without an `.ssp`, and it removes the tree walk and node construction from the
archive layer. The facade stays thin because validation plus one delegation
replaces assembly.

## Alternatives Considered
- Keep assembly in `SSP` and expose nothing on `SSD`: standalone `.ssd` stays
  uneditable, and the layering violation stays.
- Put the whole split inside `ssd.py`: grows the public facade past its
  delegation role.
- Give `SSD` file placement too: duplicates archive resolution, which
  orchestration owns.

## Consequences
- Positive: one owner per concern; `standard/ssp1/operations/ssp_binding.py`
  drops from 335 to 279 lines; `SSD.target` and `SSD.bind_parameters` become
  reusable by consumers.
- Negative: `SSP.bind_parameters` now passes `name` to two layers, each where
  it applies; `Element.add_parameter_binding` widens `source` to optional.
- Enforcement: `test_ssp_bind.py` pins `SSP` behaviour, new
  `test_ssd_bind.py` pins `SSD`.

## Verification
`pyssp_standard`: 407 passed; one pre-existing failure in
`test_ssp_add_fmu.py` (fixture has no `binaries/`). `test_ssp_bind.py` is
unchanged. New `pytest/ssp1/facade/test_ssd_bind.py`: 19 passed.
`standard/ssp1/operations/ssp_binding.py` no longer imports `Ssd1*` or touches
`elements`.

## Review Trigger
When SSP2 gains an SSM stack, or when a second consumer needs binding edits
outside an `.ssp` archive.
