---
id: IMD-004
title: Replace the SSP1 tree classes with protocols and facade construction
summary: The public surface carries no SSP version token; the SSD tree is protocols and every document is built through facade methods.
date: 2026-10-27
status: accepted
layers: [implementation, product]
state: 03-implementation/interfaces.md
artifacts:
  - pyssp_standard/tree.py
  - pyssp_standard/__init__.py
  - pyssp_standard/ssd.py
  - pyssp_standard/ssv.py
  - pyssp_standard/ssm.py
  - pyssp_standard/standard/ssp1/model/ssd_model.py
  - docs/breakdown/03-implementation/interfaces.md
  - docs/breakdown/01-product/domain-model.md
supersedes: []
superseded_by: []
related: [IMD-002, IMD-003]
---

# IMD-004: Replace the SSP1 tree classes with protocols and facade construction

## Context
IMD-003 published the SSP1 tree classes under neutral names so consumers could
stop importing `pyssp_standard.ssd`, but the names still denoted SSP1
dataclasses: consumers constructed them and stamped `ssd.xml.version = "1.0"`,
and the `Ssp1*` parameter types sat in the public surface. Version choice must
live in the facade, not in the consumer.

## Decision
The SSD tree becomes `@runtime_checkable` protocols in `pyssp_standard/tree.py`;
the `Ssp1*` parameter types leave the public surface; and documents are built
only through SSD/SSV/SSM facade methods, never by instantiating a tree class.
`SSD` owns the SSP version.

## Rationale
A protocol is the honest type for "the tree the facade exposes": any SSP version
can satisfy it without a rename, and consumers keep annotations and
`isinstance` checks. Publishing the model classes made the SSP1 implementation
the contract by accident. The construction methods are `SSD.new_system`,
`SSD.rename`, `SSD.set_default_experiment`, `System.add_component`,
`System.add_subsystem`, `System.add_connection`, `Element.add_connector`,
`Element.add_parameter_binding`, `SSV.create_parameter_set`, and
`SSM.create_mapping`.

## Alternatives Considered
- Keep the SSP1 classes exported under neutral names (IMD-003): the names hide
  the version instead of removing it.
- Rename them to `DefaultComponent`/`DefaultSystem`: visible assumption, but
  consumers still construct versioned models.
- Add SSP2 SSD/SSM so the aliases become neutral: out of scope by the
  `purpose.md` non-goal.

## Consequences
- Positive: one import rule and one construction rule; `__all__` is
  version-free; the SSP version is set in one place.
- Negative: the tree protocol is kept in step with the dataclasses by hand;
  `Element` lives in `tree.py` but not in `__all__`; `SSD.new_system` no longer
  renames the document, so callers call `rename`.
- Enforcement: `pyssp_standard` meta-tests reject version tokens in `__all__`
  and any `standard.*` import in `tree.py`/`parameters.py`;
  `pyssp_workflow/tests/test_layering.py` rejects submodule imports and
  `ssd.xml.system`/`ssd.xml.version`; `pyssp_sysml2/tests/test_layering.py`
  rejects submodule imports.

## Verification
`pyssp_standard`: 372 passed, one pre-existing failure in
`test_ssp_add_fmu.py` (the FMU fixture has no `binaries/`).
`pyssp_sysml2`: 165 passed. `pyssp_workflow`: 59 passed, 1 skipped. Root
`tests/test_sysml_fixtures.py`: 51 passed. Grep for `from pyssp_standard.` and
`import pyssp_standard.` across consumer sources and tests returns zero.

## Review Trigger
When an SSP2 SSD or SSM stack leaves the non-goal list: the protocols stay, and
the SSP2 dataclasses must satisfy them or the tree gains a neutral adapter.
